public class Item {
    private String name;
    private double price;

    // --- Constructor ---
    public Item(String name, double price) {
        this.name = name;
        this.price = price;
    }

    // --- Name Getter & Setter ---
    // getter
    public String getName() {
        return name;
    }

    // setter
    public void setName(String itemName) {
        name = itemName;
    }

    // --- Price Getter & Setter ---
    // getter
    public double getPrice() {
        return price;
    }

    // setter
    public void setPrice(double amount) {
        price = amount;
    }

}
