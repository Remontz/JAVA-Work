import java.util.ArrayList;

public class Order {
    public String name;
    public double total;
    public boolean ready;
    public ArrayList<Item> items = new ArrayList<>();

    public void addItem(Item item) {
        items.add(item);
    }

    public double getTotal() {
        for (int i = 0; i < items.size(); i++) {
            Item item = new Item();
            item = items.get(i);

            total = total + item.price;
        }
        return total;
    }
}
