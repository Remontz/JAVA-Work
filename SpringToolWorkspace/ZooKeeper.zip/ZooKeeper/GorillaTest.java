
public class GorillaTest {

	public static void main(String[] args) {
		Gorilla goku = new Gorilla();
		goku.throwSomething();
		goku.throwSomething();
		goku.throwSomething();
		goku.eatBananas();
		goku.eatBananas();
		goku.climb();
		goku.displayEnergy();
	}

}
