
public class BatTest {

	public static void main(String[] args) {
		Bat chloe = new Bat();
		
		chloe.fly();
		chloe.attackTown();
		chloe.eatHumans();
		chloe.fly();
		chloe.attackTown();
		chloe.attackTown();
		chloe.eatHumans();
		
		chloe.displayEnergy();

	}

}
