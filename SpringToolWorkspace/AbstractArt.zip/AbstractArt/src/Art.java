
public abstract class Art {
	String title;
	String author;
	String description;
	
	public abstract void viewArt();
}
