
public class TestingCalculator {

	public static void main(String[] args) {
		Calculator cal1 = new Calculator();

		cal1.performOperation(1.0, 3.0, '+');
		// cal1.thumbs();
		cal1.performOperation();

	}

}
