package com.kacygilbert.dojoRoster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoRosterApplicationTests {

	@Test
	void contextLoads() {
	}

}
