package com.kacygilbert.dojoRoster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojoRosterApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojoRosterApplication.class, args);
	}

}
